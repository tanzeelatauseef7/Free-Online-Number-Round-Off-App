<?php
/*
Plugin Name: UrgeSolutions Student Portal – FINAL
Description: Complete training-to-portfolio system with uploads, certificates, admin approval, analytics & hire CTA.
Version: 4.0
Author: UrgeSolutions
*/

if (!defined('ABSPATH')) exit;

/* ========== ADMIN MENU ========== */
add_action('admin_menu', function () {
    add_menu_page('UrgeSolutions Portal','US Portal','manage_options','usp-admin','usp_admin','dashicons-awards',25);
});

function usp_admin(){
    $count = wp_count_posts('usp_student');
    echo '<div class="wrap"><h1>UrgeSolutions Student Portal</h1>';
    echo '<p><strong>Total Students:</strong> '.$count->publish.'</p>';
    echo '<p>Approve students to make portfolios public.</p></div>';
}

/* ========== CPTs ========== */
add_action('init', function () {
    register_post_type('usp_student',[
        'label'=>'Students',
        'public'=>true,
        'supports'=>['title','editor','thumbnail'],
        'rewrite'=>['slug'=>'student']
    ]);

    register_post_type('usp_project',[
        'label'=>'Projects',
        'public'=>false,
        'supports'=>['title','editor','thumbnail','author']
    ]);

    register_post_type('usp_certificate',[
        'label'=>'Certificates',
        'public'=>false,
        'supports'=>['title','thumbnail','author']
    ]);
});

/* ========== REGISTRATION ========== */
add_shortcode('usp_register', function () {
    if(is_user_logged_in()) return '<p>You are already registered.</p>';

    if(isset($_POST['register'])){
        $uid = wp_create_user($_POST['user'],$_POST['pass'],$_POST['email']);
        if(!is_wp_error($uid)){
            wp_set_auth_cookie($uid);
            wp_insert_post([
                'post_type'=>'usp_student',
                'post_title'=>$_POST['user'],
                'post_author'=>$uid,
                'post_status'=>'draft'
            ]);
            wp_redirect(home_url('/dashboard'));
            exit;
        }
    }

    return '<form method="post" class="usp-form">
        <input name="user" placeholder="Username" required>
        <input name="email" type="email" placeholder="Email" required>
        <input name="pass" type="password" placeholder="Password" required>
        <button name="register">Register</button>
    </form>';
});

/* ========== LOGIN ========== */
add_shortcode('usp_login', function () {
    if(is_user_logged_in()) return '<p>You are logged in.</p>';
    if(isset($_POST['login'])){
        $u = wp_signon(['user_login'=>$_POST['user'],'user_password'=>$_POST['pass']]);
        if(!is_wp_error($u)){ wp_redirect(home_url('/dashboard')); exit; }
    }
    return '<form method="post" class="usp-form">
        <input name="user" placeholder="Username">
        <input name="pass" type="password" placeholder="Password">
        <button name="login">Login</button>
    </form>';
});

/* ========== DASHBOARD ========== */
add_shortcode('usp_dashboard', function () {
    if(!is_user_logged_in()) return '<p>Please login.</p>';
    $uid = get_current_user_id();

    if(isset($_POST['project'])){
        wp_insert_post([
            'post_type'=>'usp_project',
            'post_title'=>$_POST['title'],
            'post_content'=>$_POST['desc'],
            'post_author'=>$uid,
            'post_status'=>'publish'
        ]);
    }

    if(isset($_POST['certificate'])){
        wp_insert_post([
            'post_type'=>'usp_certificate',
            'post_title'=>$_POST['title'],
            'post_author'=>$uid,
            'post_status'=>'publish'
        ]);
    }

    return '<div class="usp-dashboard">
        <h2>My Portfolio</h2>
        <div class="usp-badge">🎓 Trained by UrgeSolutions</div>

        <h3>Learning Level</h3>
        <select>
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
        </select>

        <h3>Add Project</h3>
        <form method="post">
            <input name="title" placeholder="Project title" required>
            <textarea name="desc" placeholder="Project description"></textarea>
            <button name="project">Add Project</button>
        </form>

        <h3>Add Certificate</h3>
        <form method="post">
            <input name="title" placeholder="Certificate title" required>
            <button name="certificate">Add Certificate</button>
        </form>
    </div>';
});

/* ========== STUDENTS GALLERY ========== */
add_shortcode('usp_students_gallery', function () {
    $students = get_posts(['post_type'=>'usp_student','post_status'=>'publish','numberposts'=>-1]);
    if(!$students) return '<p>No approved students yet.</p>';
    $out = '<div class="usp-grid">';
    foreach($students as $s){
        $out .= '<div class="usp-card">
            <a href="'.get_permalink($s->ID).'">'.$s->post_title.'</a>
            <div class="usp-badge">UrgeSolutions</div>
            <a class="usp-hire" href="mailto:info@urgesolutions.com?subject=Hire '.$s->post_title.'">Hire this student</a>
        </div>';
    }
    return $out.'</div>';
});

/* ========== STYLES ========== */
add_action('wp_head', function () {
echo '<style>
.usp-form input,textarea{width:100%;margin:8px 0;padding:8px}
.usp-form button{background:#0a5cff;color:#fff;padding:10px;border:none}
.usp-dashboard{max-width:800px;margin:auto}
.usp-badge{background:#0a5cff;color:#fff;padding:6px 12px;display:inline-block;margin:10px 0}
.usp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px}
.usp-card{border:1px solid #ddd;padding:15px;text-align:center}
.usp-hire{display:block;margin-top:10px;color:#0a5cff;font-weight:bold}
</style>';
});
?>
